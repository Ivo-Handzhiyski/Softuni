﻿using Single_Inheritance;
using System;

namespace Farm
{
    class Startup
    {
        static void Main(string[] args)
        {
            Dog dog = new Dog();
            dog.Eat();
            dog.Bark();
        }
    }
}
 