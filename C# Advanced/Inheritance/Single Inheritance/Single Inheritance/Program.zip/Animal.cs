﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Single_Inheritance
{
    public class Animal
    {

        public string Eat()
        {
            return "eating...";
        }
    }
}
