﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Single_Inheritance
{
    public class Dog : Animal
    {
        public string Bark()
        {
            return "barking...";
        }
    }
}
