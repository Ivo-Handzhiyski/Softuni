﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    class DarkWizard : Wizard
    {
        public DarkWizard(string username, int level)
            : base(username, level)
        {

        }
    }
}
